package ForAndWhileLoops;

public class WileLoopOdd {
    public static void main (String [] args){
        System.out.println("Table of 10 Odd Number");
        int i = 0;
        while (i <=20){
            if (i%2 != 0){
                System.out.println(" " + i);
                i++;


            }
        }
    }
}

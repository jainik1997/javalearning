package ForAndWhileLoops;

public class WileLoopTableFor9 {
    public static void main (String [] args){
        System.out.println("Table of 9 ");
        int i = 1;
        int j = 9;
        while (i<=10){
            System.out.println(j +" * " + i+" = " + (i*j));
            i++;
        }
    }
}

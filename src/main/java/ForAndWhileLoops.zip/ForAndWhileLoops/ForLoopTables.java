package ForAndWhileLoops;

public class ForLoopTables {
    public static void main (String [] args){
        System.out.println("Table of 10");
        int t =10;
        for (int k=1; k<=10; k++){
            System.out.println(t +" * " + k+" = " + (t*k));
        }
    }
}

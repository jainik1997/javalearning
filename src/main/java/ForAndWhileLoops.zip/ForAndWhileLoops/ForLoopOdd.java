package ForAndWhileLoops;

public class ForLoopOdd {
    public static void main (String [] args){
        System.out.println("List of 10 Even NUMBERS");
        int j =20;
        for (int i=1; i<=j; i++){
            if(i%2 != 0){
                System.out.println(i+"");

            }
        }
    }
}

package homework;

public class DataTypesArithmetic2 {
    public static void main(String[] args){
        //short example
        short k = 10001;
        System.out.println(k);
    }
}

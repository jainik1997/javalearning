package homework;

public class PositivNegativ {
    public static void main (String[]args) {
        int positive = 5;
        int negitive =-1;
        if (positive > negitive){
            System.out.println ("Number is positive");
        }
          else if (positive < negitive){
            System.out.println ("Number is nagative");
        }
          else {
            System.out.println ("Number is zero");
        }
    }
}

package homework;

public class DataTypesArithmetic4 {
    public static void main (String []args){
        //long exampl
        long num = 67000000000000l;
        System.out.println(num);
    }
}

package homework;

public class DataTypesArithmetic
{public static void main (String []args){
    byte n, a;

    n=127;
    a=-128;
    System.out.println(n);
    System.out.println(a);
}
}
